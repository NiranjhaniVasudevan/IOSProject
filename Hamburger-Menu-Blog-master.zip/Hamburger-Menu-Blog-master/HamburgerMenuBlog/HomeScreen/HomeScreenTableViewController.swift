//
//  HomeScreenTableViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/16/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit
import Firebase

class HomeScreenTableViewController: UITableViewController {

    var boardValuesArrayDocument : Array<QueryDocumentSnapshot> = []
    var data : [MembersHelper]?
    var boardNamesArray : [BoardModel] = []
     var detailBoard : BoardModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        let user = Auth.auth().currentUser
        let id = user?.uid
        data = []
        FireBaseService.getBoard() { boardValues, error in
            self.boardNamesArray = []
            self.boardValuesArrayDocument = []
            for document in boardValues.documents {
                for doc in document.data() {
                    if (doc.key == "UserId" && id == doc.value as! String) {
                        self.boardValuesArrayDocument.append(document)
                    }
                }
            }
            
            for userBoardDocuments in self.boardValuesArrayDocument {
                print(userBoardDocuments.documentID)
                for doc in userBoardDocuments.data() {
                    if doc.key == "Boardname" {
                        self.boardNamesArray.append(BoardModel(boardName:doc.value as! String, boardId: userBoardDocuments.documentID))
                    }
                   
                }
            }
            
             //self.tableView.reloadData()
        }
            
    }


    override func viewWillAppear(_ animated: Bool) {
        // Reload data
        let user = Auth.auth().currentUser
        let id = user?.uid
        super.viewDidLoad()
        data = []
        FireBaseService.getBoard() { boardValues, error in
            self.boardNamesArray = []
            self.boardValuesArrayDocument = []
            for document in boardValues.documents {
                for doc in document.data() {
                    if (doc.key == "UserId" && id == doc.value as! String) {
                        self.boardValuesArrayDocument.append(document)
                    }
                }
            }
            
            for userBoardDocuments in self.boardValuesArrayDocument {
                for doc in userBoardDocuments.data() {
                    if doc.key == "Boardname" {
                        self.boardNamesArray.append(BoardModel(boardName:doc.value as! String, boardId: userBoardDocuments.documentID))
                    }
                }
            }
            
            self.tableView.reloadData()
        }
        //tableView.clear
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BoardCell", for: indexPath)
            as! HomeScreenTableViewCell
        print(boardNamesArray[indexPath.row])
        cell.boardLabel.text = boardNamesArray[indexPath.row].boardName

        return cell
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (boardNamesArray.count)
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //        if section < (Customer?.count)! {
        //            return "Customer ID : \(Customer![section+1]?.name)"
        //        }
        
        return nil
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        print(segue.destination)
        if segue.destination is ViewController
        {
            let vc = segue.destination as? ViewController
            vc!.detailBoard = detailBoard
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let currentCell = tableView.cellForRow(at: indexPath)! as! HomeScreenTableViewCell
        
        detailBoard =  boardNamesArray[indexPath.row]
        self.performSegue(withIdentifier: "BoardDetailView", sender: self)
        
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            FireBaseService.removeBoard(withID: boardNamesArray[indexPath.row].boardId) { value, error in
                print(value)
            }
            boardNamesArray.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
  
}
