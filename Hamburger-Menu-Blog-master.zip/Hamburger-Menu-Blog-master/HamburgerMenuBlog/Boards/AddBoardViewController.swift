//
//  AddBoardViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/16/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit

class AddBoardViewController: UIViewController {

    @IBOutlet weak var notes: UITextField!
    @IBOutlet weak var boardName: UITextField!
    var selectedBoardValue : String?
    var selctedNotes : String?
    var heredata : [MembersHelper]? = []
    var members : Array<String> = []
    override func viewDidLoad() {
        super.viewDidLoad()
        notes.underlined()
        boardName.underlined()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        boardName.text = selectedBoardValue
        notes.text = selctedNotes
        for value in heredata! {
            members.append(value.title)
        }
        
    }
    

    @IBAction func createBoardButton(_ sender: Any) {
        
        FireBaseService.saveNewBoard(name: boardName.text!, members: members, notes: notes.text!) { status, error in
            print(status)
            if(error == nil){
                self.navigationController?.popViewController(animated: true)
                self.dismiss(animated: true, completion: nil)
            }
            else {
                // throw error
            }
        }
        
    }
    
    @IBAction func unwindFromAddMembers(_ sender: UIStoryboardSegue) {
        
        if sender.source is MembersTableViewController
        {
            if let senderVC = sender.source as? MembersTableViewController {
                heredata = senderVC.data
                selectedBoardValue = senderVC.sendboardName
                selctedNotes = senderVC.sendnotes
                for data in heredata! {
                    print(data.title)
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is MembersTableViewController
        {
            let vc = segue.destination as? MembersTableViewController
            vc!.boardName = boardName.text!
            vc!.notes = notes.text!
        }
    }
}
