//
//  InProgressTableViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/21/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit
import Firebase

class InProgressTableViewController: UITableViewController {
    
    var detailBoard : BoardModel?
    var taskscollectionFortable : [TaskModel] = []
    var taskforBoard : Array<QueryDocumentSnapshot> = []
    var taskforInProgBoard : Array<QueryDocumentSnapshot> = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        FireBaseService.gettask() { taskdocument, Error in
            self.taskscollectionFortable = []
            self.taskforBoard = []
            self.taskforInProgBoard = []
            // filter task based on board
            for document in taskdocument.documents {
                for task in document.data() {
                    if (task.key == "BoardId" && self.detailBoard?.boardId == task.value as! String){
                        self.taskforBoard.append(document)
                    }
                }
            }
            //filter task based on status
            for doc in self.taskforBoard {
                for open in doc.data() {
                    if(open.key == "status" && "In Progress" == open.value as! String) {
                        self.taskforInProgBoard.append(doc)
                    }
                }
            }
            
            
            // convert to display on table
            for userTaskDocuments in self.taskforInProgBoard {
                print(userTaskDocuments.documentID)
                for doc in userTaskDocuments.data() {
                    if doc.key == "taskname" {
                        self.taskscollectionFortable.append(TaskModel(taskid: userTaskDocuments.documentID, taskName: doc.value as! String))
                    }
                }
            }
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidLoad()
        FireBaseService.gettask() { taskdocument, Error in
            self.taskscollectionFortable = []
            self.taskforBoard = []
            self.taskforInProgBoard = []
            // filter task based on board
            for document in taskdocument.documents {
                for task in document.data() {
                    if (task.key == "BoardId" && self.detailBoard?.boardId == task.value as! String){
                        self.taskforBoard.append(document)
                    }
                }
            }
            //filter task based on status
            for doc in self.taskforBoard {
                for open in doc.data() {
                    if(open.key == "status" && "In Progress" == open.value as! String) {
                        self.taskforInProgBoard.append(doc)
                    }
                }
            }
            
            
            // convert to display on table
            for userTaskDocuments in self.taskforInProgBoard {
                print(userTaskDocuments.documentID)
                for doc in userTaskDocuments.data() {
                    if doc.key == "taskname" {
                        self.taskscollectionFortable.append(TaskModel(taskid: userTaskDocuments.documentID, taskName: doc.value as! String))
                    }
                }
            }
            
            self.tableView.reloadData()
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InProgTaskCell", for: indexPath)
            as! InProgressTableViewCell
        print(taskscollectionFortable[indexPath.row])
        cell.taskname.text = taskscollectionFortable[indexPath.row].taskName
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (taskscollectionFortable.count)
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //        if section < (Customer?.count)! {
        //            return "Customer ID : \(Customer![section+1]?.name)"
        //        }
        
        return nil
    }
    



}
