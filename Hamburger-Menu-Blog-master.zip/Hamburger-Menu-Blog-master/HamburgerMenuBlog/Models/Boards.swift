//
//  Boards.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/17/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import Foundation

struct BoardModel {
    var boardName : String
    var boardId : String
}
