//
//  TaskHelper.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/21/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import Foundation

struct TasklistDetail {
    var boardId : String
    var userId : String
    var checklist : [String : Any]
    var comments : String
    var duedate : String
    var status : String
    var taskname : String
    var taskid : String
    
}

struct TaskModel {
    var taskid : String
    var taskName : String
}
