import Foundation
import UIKit

class MembersHelper {
    public var item: Model
    
    var isSelected = false
    
    var title: String {
        return item.name
    }
    
    init(item: Model) {
        self.item = item
    }
}


