//
//  MembersTableViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/17/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class MembersTableViewController: UITableViewController {
    var items = [MembersHelper]()
    var data : [MembersHelper]?
    var boardName : String?
    var notes : String?
    var sendboardName : String?
    var sendnotes : String?
    var userArray : Array<Model> = []
    var addBoardController = AddBoardViewController()
    var didToggleSelection: ((_ hasSelection: Bool) -> ())? {
        didSet {
            didToggleSelection?(!selectedItems.isEmpty)
        }
    }
    
    var selectedItems: [MembersHelper] {
        return items.filter { return $0.isSelected }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        FireBaseService.getRegsiteredUser() { value, error in
            self.userArray = []
            for doc in value.documents {
                for val in doc.data() {
                    self.userArray.append(Model(name: val.value as! String))
                }
            }
            self.items = self.userArray.map { MembersHelper(item: $0) }
            self.tableView.reloadData()
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return items.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MemberCell", for: indexPath) as? MembersTableViewCell
        cell?.item = items[indexPath.row]
        
        // select/deselect the cell
        if items[indexPath.row].isSelected {
            if !cell!.isSelected {
                tableView.selectRow(at: indexPath, animated: false, scrollPosition: .none)
            }
        } else {
            if cell!.isSelected {
                tableView.deselectRow(at: indexPath, animated: false)
            }
        }
        
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // update ViewModel item
        items[indexPath.row].isSelected = true
        
        didToggleSelection?(!selectedItems.isEmpty)
    }
    
    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        // update ViewModel item
        items[indexPath.row].isSelected = false
        
        didToggleSelection?(!selectedItems.isEmpty)
    }
    
    override func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        if selectedItems.count > 10 {
            return nil
        }
        return indexPath
    }

    @IBAction func selected(_ sender: Any) {
        
        print(selectedItems.map { $0.title })
        data = selectedItems
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
            data = selectedItems
            sendboardName = boardName
            sendnotes = notes
            
    }
    
}
