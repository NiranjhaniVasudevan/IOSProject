//
//  MembersTableViewCell.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/17/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit

class MembersTableViewCell: UITableViewCell {

    
    var item: MembersHelper? {
        didSet {
            print(item)
            userName?.text = item?.title
        }
    }
    
    @IBOutlet weak var userName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        accessoryType = selected ? .checkmark : .none
    }

}
