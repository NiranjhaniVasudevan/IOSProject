//
//  RegisterViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/15/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit

import FirebaseAuth

class RegisterViewController: UIViewController {


    @IBOutlet weak var emailUserName: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var confirmPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func register(_ sender: Any) {
        
        if(password.text == confirmPassword.text) {
        
            Auth.auth().createUser(withEmail: emailUserName.text!, password: password.text!){ (user, error) in
                    if error == nil {
                        FireBaseService.saveRegisteredUser(email: self.emailUserName.text!) { status, error in
                            print(status)
                            print("Succesfully Signed in")
                        }
                    }
                    else{
                        let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        
                        alertController.addAction(defaultAction)
                        self.present(alertController, animated: true, completion: nil)
                    }
            }
        }
        else{
            let alertController = UIAlertController(title: "Error", message: "Please type the password correctly", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }

}
