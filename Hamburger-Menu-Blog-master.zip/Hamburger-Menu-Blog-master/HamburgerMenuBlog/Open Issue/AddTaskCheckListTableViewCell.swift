//
//  AddTaskCheckListTableViewCell.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/18/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit

protocol ChangeButton {
    
    func changeButton(checked : Bool , index : Int)
}

class AddTaskCheckListTableViewCell: UITableViewCell {

    @IBOutlet weak var taskname: UILabel!
    @IBOutlet weak var checkboxOutlet: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func checkBoxClicked(_ sender: Any) {
        
        if tasks![indexP!].checked {
            delegate?.changeButton(checked: false, index: indexP!)
        }
        else {
             delegate?.changeButton(checked: true, index: indexP!)
        }
        
    }
    
    var delegate : ChangeButton?
    var indexP : Int?
    var tasks : [Task]?
}
