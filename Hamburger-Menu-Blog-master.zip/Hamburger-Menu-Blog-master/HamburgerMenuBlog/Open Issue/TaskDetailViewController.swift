//
//  TaskDetailViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/21/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit
import Firebase
extension String
{
    func toDate( dateFormat format  : String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        return dateFormatter.date(from: self)!
    }
    
}
class TaskDetailViewController: UIViewController,UITableViewDelegate, UITableViewDataSource, ChangeButton,UIPickerViewDelegate, UIPickerViewDataSource{
 
    

    @IBOutlet weak var tasknameTxt: UITextField!
    @IBOutlet weak var dueDateTxt: UIDatePicker!
    @IBOutlet weak var commentTxt: UITextField!
    
    
    @IBOutlet weak var checkItemsTxt: UITextField!
    @IBOutlet weak var pickerView: UIPickerView!
    
    var detailTask : TaskModel?
    var boardId : String?
    var userId : String?
    var checklist : Array<[String : Any]> = []
    var comments : String?
    var duedate : String?
    var status : String?
    var taskname : String?
    var taskid : String?
    
    @IBOutlet weak var tableView: UITableView!
     var tasks: [Task] = []
    
    var checklistid : String?
     var docmentValues : QueryDocumentSnapshot?
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        pickerView.delegate = self
        pickerView.dataSource = self
        FireBaseService.gettask() { taskdocument, Error in
        
            for document in taskdocument.documents {
                
                    if(document.documentID == self.detailTask?.taskid) {
                        self.docmentValues = document
                    }
             
                }
        
        for val in (self.docmentValues?.data())! {
            
            switch(val.key) {
            case "BoardId":
                self.boardId = val.value as? String
            case "taskname":
                self.taskname = val.value as? String
            case "dueDate":
                self.duedate = val.value as? String
            case "checklist":
                self.checklistid = val.value as? String
            case "status":
                self.status = val.value as? String
            default :
                print("default")
            }
        }
        
         FireBaseService.getCheckList() { checklistdocument, Error in
            
                for document in checklistdocument.documents {
                    for check in document.data() {
                         if(check.key == "id") {
                            print(check.value as! String)
                        }
                        if(check.key == "id" &&  self.checklistid ==  check.value as? String) {
                            self.checklist.append(document.data())
                        }
                    }
                }
            
                let date = self.duedate?.toDate(dateFormat: "yyyy-MM-dd HH:mm:ss")
                print("Date is \(date)")

                self.tasknameTxt.text = self.taskname
                self.dueDateTxt.date = date!
                self.commentTxt.text = self.comments
                for items in  self.checklist {
                    let object = Task(name: items["checklisttask"] as! String, checked: items["status"] as! Bool)
                    self.tasks.append(object)
                }
            
                self.tableView.reloadData()
            }

        }
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "task", for: indexPath)
            as! AddTaskCheckListTableViewCell
        cell.taskname.text = tasks[indexPath.row].name
        if(tasks[indexPath.row].checked) {
            cell.checkboxOutlet.setBackgroundImage(UIImage(named: "CheckboxTikked"), for: UIControlState.normal)
        }
        else
        {
            cell.checkboxOutlet.setBackgroundImage(UIImage(named: "CheckboxOutline"), for: UIControlState.normal)
        }
        cell.delegate = self
        cell.indexP = indexPath.row
        cell.tasks = tasks
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tasks.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    @IBAction func addButton(_ sender: Any) {
        if(checkItemsTxt.text != "") {
            tasks.append(Task(name: checkItemsTxt.text!,checked: false))
            tableView.reloadData()
            checkItemsTxt.text = ""
        }
        
    }
    
    func changeButton(checked: Bool, index: Int) {
        tasks[index].checked = checked
        tableView.reloadData()
    }
    
    
    @IBAction func updateButton(_ sender: Any) {
        
        
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return statusArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        statusTxt = statusArray[row]
        return statusArray[row]
    }
    func pickerView( pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        statusTxt = statusArray[row]
    }
    
}
