//
//  AddOpenIssueViewController.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/18/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import UIKit

class AddOpenIssueViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ChangeButton, UIPickerViewDelegate, UIPickerViewDataSource{
  
    @IBOutlet weak var pickerView: UIPickerView!
    var statusTxt : String?
    @IBOutlet weak var taskName: UITextField!
    
    @IBOutlet weak var dueDatePicker: UIDatePicker!
    var detailBoardVales : BoardModel?
    
    @IBOutlet weak var comments: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var checklistTask: UITextField!
    var tasks: [Task] = []
    let statusArray = ["Open","In Progress","Completed"]
    override func viewDidLoad() {
        super.viewDidLoad()
        taskName.underlined()
        comments.underlined()
        checklistTask.underlined()
        pickerView.delegate = self
        pickerView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "task", for: indexPath)
            as! AddTaskCheckListTableViewCell
        cell.taskname.text = tasks[indexPath.row].name
        if(tasks[indexPath.row].checked) {
            cell.checkboxOutlet.setBackgroundImage(UIImage(named: "CheckboxTikked"), for: UIControlState.normal)
        }
        else
        {
            cell.checkboxOutlet.setBackgroundImage(UIImage(named: "CheckboxOutline"), for: UIControlState.normal)
        }
        cell.delegate = self
        cell.indexP = indexPath.row
        cell.tasks = tasks
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tasks.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    @IBAction func addTaskInChecklist(_ sender: Any) {
        if(checklistTask.text != "") {
            tasks.append(Task(name: checklistTask.text!,checked: false))
            tableView.reloadData()
            checklistTask.text = ""
        }
    }
    
    

    @IBAction func createTask(_ sender: Any) {
 
        FireBaseService.saveNewtask(taskname: taskName.text!, BoardId: (detailBoardVales?.boardId)!, dueDate: dueDatePicker.date, comments: comments.text!, checklist: tasks, status: statusTxt!){ value, error in
            FireBaseService.savechecklist(checklistkey: value, checklist: self.tasks) {
                value , error in
                print(value)
            }
            
        }
        
        
    }
    
    func changeButton(checked: Bool, index: Int) {
        tasks[index].checked = checked
        tableView.reloadData()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return statusArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        statusTxt = statusArray[row]
        return statusArray[row]
    }
    func pickerView( pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
       statusTxt = statusArray[row]
    }
    
}
class Task {
    var name = ""
    var checked = false
    
    convenience init(name: String,checked: Bool) {
        self.init()
        self.name = name
        self.checked = checked
    }
}
