//
//  FirebaseService.swift
//  HamburgerMenuBlog
//
//  Created by Dinesh Maria Antony Packianathan Jerome on 4/16/19.
//  Copyright © 2019 Erica Millado. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore
import FirebaseDatabase
extension UITextField {
    
    func underlined(){
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor(red: 0, green: 0.5294, blue: 0.5569, alpha: 1.0).cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height: self.frame.size.height)
        border.borderWidth = width
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
}

class FireBaseService {
   
    static var newBoardRequestCompleted: Bool = false
   static func saveNewBoard(name: String, members: Array<String>, notes : String, completion: @escaping (String, Error?)-> Void) {
    newBoardRequestCompleted = false
    let userName = getCurrentUserName()
        let firestore = Firestore.firestore()
        let boardCollection = firestore.collection("Board")
    
         boardCollection.addDocument(data: ["Boardname" : name,
                                           "notes" : notes,
                                           "members" : members,
                                           "UserId" : userName] as [String : Any])
        { error in
            print(error)
            if error != nil {
                completion("failed",error)
            } else {
                completion("Success",error)
            }
        }
    }
    
    static func getBoard(completion: @escaping (QuerySnapshot, Error?)-> Void) {
        
        Firestore.firestore().collection("Board").getDocuments() { (querySnapshot, err) in
            if let err = err {
               // completion(nil,err)
                print(err)
            } else {
                completion(querySnapshot!,err)
            }
        }
        
        
    }
    
    
    static public func removeBoard(withID: String,completion: @escaping (Bool, Error?)-> Void)  {
        
        Firestore.firestore().collection("Board").document(withID).delete(){ err in
            if let err = err {
               completion(false, nil)
            } else {
                completion(true, nil)
            }
        }
    }
    
    
    static func saveNewtask(taskname: String, BoardId: String, dueDate: Date, comments: String,  checklist: Array<Task>, status : String, completion: @escaping (String, Error?)-> Void) {
        newBoardRequestCompleted = false
        let userName = getCurrentUserName()
        let firestore = Firestore.firestore()
        let taskCollection = firestore.collection("Tasks")
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd hh:mm:ss"
        let stringdueDate = df.string(from: dueDate)
        let ref = Database.database().reference().child("Tasks")
        let key = ref.childByAutoId().key
       // var date = String(dueDate)
        taskCollection.addDocument(data: ["taskname" : taskname,
                                           "BoardId" : BoardId,
                                           "UserId" : userName,
                                           "dueDate" : stringdueDate,
                                           "comments" : comments,
                                           "checklist" : key,
                                           "status" : status] as [String : Any])
        { error in
            print(error)
            if error != nil {
                completion("",error)
            } else {
                completion(key!,error)
            }
        }
    }
    

    
    static func savechecklist(checklistkey: String, checklist: Array<Task>,completion: @escaping (Bool, Error?)-> Void) {
        newBoardRequestCompleted = false
        let firestore = Firestore.firestore()
        let checklistCollection = firestore.collection("Checkist")
        // var date = String(dueDate)
        for task in checklist {
        checklistCollection.addDocument(data: ["checklisttask": task.name,
            "status": task.checked,
            "id": checklistkey] as [String : Any])
        { error in
            print(error)
            if error != nil {
                completion(false,error)
            } else {
                completion(true,error)
            }
        }
        }
       
    }
    
    static func gettask(completion: @escaping (QuerySnapshot, Error?)-> Void) {
        
        Firestore.firestore().collection("Tasks").getDocuments() { (querySnapshot, err) in
            if let err = err {
                // completion(nil,err)
                print(err)
            } else {
                completion(querySnapshot!,err)
            }
        }
        
        
    }
    
    static func getCheckList(completion: @escaping (QuerySnapshot, Error?)-> Void) {
        
    
        Firestore.firestore().collection("Checkist").getDocuments { (querySnapshot, err) in
            if let err = err {
                // completion(nil,err)
                print(err)
            } else {
                completion(querySnapshot!,err)
            }
        }
        
        
    }
    
    
    
    static private func getCurrentUserName() -> String {
        let user = Auth.auth().currentUser
        return user?.uid ?? ""
    }
    
    static func saveRegisteredUser(email: String, completion: @escaping (String, Error?)-> Void) {
        let firestore = Firestore.firestore()
        let usersCollection = firestore.collection("Users")
        
        usersCollection.addDocument(data: ["emailId" : email] as [String : Any])
        { error in
            print(error)
            if error != nil {
                completion("failed",error)
            } else {
                completion("Success",error)
            }
        }
    }
    static func getRegsiteredUser(completion: @escaping (QuerySnapshot, Error?)-> Void) {
        
        Firestore.firestore().collection("Users").getDocuments() { (querySnapshot, err) in
            if let err = err {
                // completion(nil,err)
                print(err)
            } else {
                completion(querySnapshot!,err)
            }
        }
    }
    

}

